import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ali-back',
  templateUrl: './ali-back.component.html',
  styleUrls: ['./ali-back.component.scss']
})
export class AliBackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
