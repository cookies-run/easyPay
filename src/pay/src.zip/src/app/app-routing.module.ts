import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './loginpage/loginpage.component'
import { AppComponent } from './app.component'
import { HomepageComponent } from './homepage/homepage.component'
import { CheckPowerComponent } from './check-power/check-power.component';
import { StudentinfoComponent } from './studentinfo/studentinfo.component';
import { IncreasebillComponent } from './increasebill/increasebill.component';
import { HistorybillComponent } from './historybill/historybill.component';
import { AliBackComponent } from './ali-back/ali-back.component';
import { SchoolInfoComponent } from './school-info/school-info.component';
import { FixStudentInfoComponent } from './fix-student-info/fix-student-info.component';

const routes: Routes = [
   { path: '', redirectTo: '/login', pathMatch: 'full' },
   { path: 'login',  component: LoginComponent},
   { path: 'home',  component: HomepageComponent,
   children: [
          {path: 'checkPower', component: CheckPowerComponent},
          {path: 'addbill', component: IncreasebillComponent},
          {path: 'studInfo', component: StudentinfoComponent},
          {path: 'hisbill', component: HistorybillComponent},
          {path: 'aliback', component: AliBackComponent},
          {path: 'SchoolInfo', component: SchoolInfoComponent},
          {path: 'fixStudentInfo', component: FixStudentInfoComponent}
        ]}
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
