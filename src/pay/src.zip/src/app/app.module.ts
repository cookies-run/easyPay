import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { AppRoutingModule }     from './app-routing.module'; //路由模块
import {HashLocationStrategy, LocationStrategy} from '@angular/common';// 路由跳转(保证路由能正常跳转)
import { Router } from '@angular/router'; // 路由跳转
import { HttpModule}    from '@angular/http'; // 服务器请求
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; //动画；
import { Component,Input } from '@angular/core';
import { NgClass } from '@angular/common';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {HttpClientModule} from'@angular/common/http'





import { AppComponent } from './app.component';
import {AppService} from './app.service'; // 自定义服务模块
import { LoginComponent } from './loginpage/loginpage.component';
import { HeaderComponent } from './header/header.component';
import { TabsModule } from 'ngx-bootstrap';
import { HomepageComponent } from './homepage/homepage.component';
import { CheckPowerComponent } from './check-power/check-power.component';
import { StudentinfoComponent } from './studentinfo/studentinfo.component';
import { IncreasebillComponent } from './increasebill/increasebill.component';
import { HistorybillComponent } from './historybill/historybill.component';
import { AliBackComponent } from './ali-back/ali-back.component';
import { SchoolInfoComponent } from './school-info/school-info.component';
import { QRCodeModule } from 'angular2-qrcode';
import { FixStudentInfoComponent } from './fix-student-info/fix-student-info.component';
import { NgZorroAntdModule } from 'ng-zorro-antd'; //zrrro ui 组件

@NgModule({
  declarations:[
    CheckPowerComponent,
    StudentinfoComponent,
    IncreasebillComponent,
    HistorybillComponent,
    AliBackComponent,
    SchoolInfoComponent,
    FixStudentInfoComponent,
    AppComponent,
    LoginComponent,
    HomepageComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    QRCodeModule,
    NgZorroAntdModule.forRoot()
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy},AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
