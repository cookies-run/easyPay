import { Component,OnInit,ViewChild,Input } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import {Md5} from "ts-md5/dist/md5";
import {AppService} from '../app.service';

@Component({
  selector: 'loginpage',
  templateUrl:'./loginpage.component.html',
  styleUrls:['./loginpage.component.scss'],

})
export class LoginComponent {
    public params:any = {
        logname :'',
        password:''
    }
    public endpoint:string = 'login/loginIn?';
    public hintContent:string = '';


    constructor(private router: Router,private appService:AppService) {}
    Login () {
       if(this.params.logname ==''){
          this.hintContent ='登录名不能为空';
         return;
       }
       if(this.params.password ==''){
         this.hintContent ='password is invalid';
         return;
       }
       this.params.password=Md5.hashStr(this.params.password);
         this.loginService(this.endpoint,this.params);
        // this.router.navigate(['/home/checkPower']);
    }

     loginService(endpoint,params): void {
        this.appService.get(endpoint,params).subscribe(data => {
          if(data.json().suc){
            this.router.navigate(['/home/checkPower']);
          }else{
            this.hintContent = data.json().msg;
          }
          });
     }

   ngOnInit(): void {
     }

}
