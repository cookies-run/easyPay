import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-historybill',
  templateUrl: './historybill.component.html',
  styleUrls: ['./historybill.component.scss']
})
export class HistorybillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
